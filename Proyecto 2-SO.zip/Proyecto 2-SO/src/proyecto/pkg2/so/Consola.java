package proyecto.pkg2.so;

public class Consola {

    public int ID;
    public int contador;
    public int Prioridad;

    public Consola(int ID, int contador, int Prioridad) {
        this.ID = ID;
        this.contador = contador;
        this.Prioridad = Prioridad;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getContador() {
        return contador;
    }

    public void setContador(int contador) {
        this.contador = contador;
    }

    public int getPrioridad() {
        return Prioridad;
    }

    public void setPrioridad(int Prioridad) {
        this.Prioridad = Prioridad;
    }

}