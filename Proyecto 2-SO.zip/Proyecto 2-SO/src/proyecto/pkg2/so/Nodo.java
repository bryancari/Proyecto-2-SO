package proyecto.pkg2.so;

public class Nodo<Consola> {

    public Consola elemento;
    public Nodo<Consola> siguiente;

    public Nodo(Consola elemento, Nodo<Consola> siguiente) {
        this.elemento = elemento;
        this.siguiente = siguiente;
    }

    public Consola getElemento() {
        return elemento;
    }

    public void setElemento(Consola elemento) {
        this.elemento = elemento;
    }

    public Nodo<Consola> getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(Nodo<Consola> siguiente) {
        this.siguiente = siguiente;
    }

}