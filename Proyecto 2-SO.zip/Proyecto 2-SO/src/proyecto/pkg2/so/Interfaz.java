package proyecto.pkg2.so;

import javax.swing.JOptionPane;

public class Interfaz extends javax.swing.JFrame {

    int ID = 1;
    Cola<Consola> Cola1 = new Cola();
    Cola<Consola> Cola2 = new Cola();
    Cola<Consola> Cola3 = new Cola();
    Cola<Consola> ColaRep = new Cola();
    Proceso simul;

    public Interfaz() {
        initComponents();
        SalirBtn.setVisible(false);
        AgregarConsolBtn.setVisible(false);
        ColaNivel1.setVisible(false);
        ColaNivel2.setVisible(false);
        ColaNivel3.setVisible(false);
        ColaREP.setVisible(false);
        jScrollPane2.setVisible(false);
        jScrollPane3.setVisible(false);
        jScrollPane4.setVisible(false);
        jScrollPane5.setVisible(false);
        ConsolRevis.setVisible(false);
        Admintxt.setVisible(false);
        DayTxT.setVisible(false);
        jLabel1.setVisible(false);
        jLabel2.setVisible(false);
        jLabel3.setVisible(false);
        jLabel4.setVisible(false);
        jLabel5.setVisible(false);
        jLabel6.setVisible(false);
        jLabel7.setVisible(false);
        jLabel8.setVisible(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        IniciarSimulBtn = new javax.swing.JButton();
        SalirBtn = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        ColaNivel3 = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        ColaREP = new javax.swing.JTable();
        jScrollPane4 = new javax.swing.JScrollPane();
        ColaNivel1 = new javax.swing.JTable();
        jScrollPane5 = new javax.swing.JScrollPane();
        ColaNivel2 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        ConsolRevis = new javax.swing.JTextField();
        Admintxt = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        AgregarConsolBtn = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        DayTxT = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        IniciarSimulBtn.setText("INICIAR SIMULACIÓN");
        IniciarSimulBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IniciarSimulBtnActionPerformed(evt);
            }
        });
        getContentPane().add(IniciarSimulBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 210, 150, 30));

        SalirBtn.setText("SALIR");
        SalirBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SalirBtnActionPerformed(evt);
            }
        });
        getContentPane().add(SalirBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 10, 70, 30));

        ColaNivel3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "ID", "Contador"
            }
        ));
        jScrollPane2.setViewportView(ColaNivel3);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 80, 200, 110));

        ColaREP.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "ID", "Prioridad", "Contador"
            }
        ));
        jScrollPane3.setViewportView(ColaREP);

        getContentPane().add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 320, 390, 110));

        ColaNivel1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "ID", "Contador"
            }
        ));
        jScrollPane4.setViewportView(ColaNivel1);

        getContentPane().add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 80, 200, 110));

        ColaNivel2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "ID", "Contador"
            }
        ));
        jScrollPane5.setViewportView(ColaNivel2);

        getContentPane().add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 80, 200, 110));

        jLabel1.setText("Prioridad de Nivel 3");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 50, -1, -1));

        jLabel2.setText("Prioridad de Nivel 1");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 50, -1, -1));

        jLabel3.setText("Prioridad de Nivel 2");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 50, -1, -1));

        jLabel4.setText("Nintendo Super Switch que necesitan Mejoras o Reparaciones");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 290, -1, -1));

        jLabel5.setText("Robot Revisando la Consola (ID)");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 240, -1, -1));

        ConsolRevis.setText("--------");
        getContentPane().add(ConsolRevis, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 240, 40, -1));

        Admintxt.setText("Esperando");
        getContentPane().add(Admintxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 340, 170, -1));

        jLabel6.setText("Administrador");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 340, -1, -1));

        AgregarConsolBtn.setText("AGREGAR CONSOLA");
        AgregarConsolBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AgregarConsolBtnActionPerformed(evt);
            }
        });
        getContentPane().add(AgregarConsolBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 390, -1, -1));

        jLabel7.setText("Consolas a Revisar");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 10, -1, -1));

        jLabel8.setText("Día");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 20, 20, 20));

        DayTxT.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        DayTxT.setText("0");
        getContentPane().add(DayTxT, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 20, 80, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void IniciarSimulBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IniciarSimulBtnActionPerformed
        JOptionPane.showMessageDialog(rootPane, "Bienvenido a la simulación del robot detector de errores\n"
                                              + "de la siguiente generación de consolas Nintendo Super Switch.\n"
                                              + "Donde se revisaran las consolas y se decidirá si estan listas\n"
                                              + "para salir al mercado, si necesitan volver a ser revisadas o si\n"
                                              + "necesitan alguna mejora.");
        IniciarSimulBtn.setVisible(false);
        AgregarConsolBtn.setVisible(true);
        SalirBtn.setVisible(true);
        ColaNivel1.setVisible(true);
        ColaNivel2.setVisible(true);
        ColaNivel3.setVisible(true);
        ColaREP.setVisible(true);
        jScrollPane2.setVisible(true);
        jScrollPane3.setVisible(true);
        jScrollPane4.setVisible(true);
        jScrollPane5.setVisible(true);
        ConsolRevis.setVisible(true);
        Admintxt.setVisible(true);
        DayTxT.setVisible(true);
        jLabel1.setVisible(true);
        jLabel2.setVisible(true);
        jLabel3.setVisible(true);
        jLabel4.setVisible(true);
        jLabel5.setVisible(true);
        jLabel6.setVisible(true);
        jLabel7.setVisible(true);
        jLabel8.setVisible(true);
        simul = new Proceso(Cola1, Cola2, Cola3, ColaRep,
                ColaNivel1, ColaNivel2, ColaNivel3, ColaREP, Admintxt, ConsolRevis, ID, DayTxT);
        simul.start();
    }//GEN-LAST:event_IniciarSimulBtnActionPerformed

    private void SalirBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalirBtnActionPerformed
        System.exit(0);
    }//GEN-LAST:event_SalirBtnActionPerformed

    private void AgregarConsolBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AgregarConsolBtnActionPerformed
        int prio = (int) (Math.random() * 3) + 1;
        Consola con;
        int siz;
        switch (prio) {
            case 1:
                simul.con1.Encolar(new Consola(simul.ID, 0, 1));
                simul.ID++;
                siz = simul.con1.size();
                if (siz <= 100) {
                    for (int j = 0; j < siz; j++) {
                        if (j < 100) {
                            con = simul.con1.primero();
                            simul.con1.DesEncolar();
                            simul.con1.Encolar(con);
                            ColaNivel1.setValueAt(con.ID, j, 0);
                            ColaNivel1.setValueAt(con.contador, j, 1);
                        }
                    }
                }
                break;
            case 2:
                simul.con2.Encolar(new Consola(simul.ID, 0, 2));
                simul.ID++;
                siz = simul.con2.size();
                if (siz <= 100) {
                    for (int j = 0; j < siz; j++) {
                        if (j < 100) {
                            con = simul.con2.primero();
                            simul.con2.DesEncolar();
                            simul.con2.Encolar(con);
                            ColaNivel2.setValueAt(con.ID, j, 0);
                            ColaNivel2.setValueAt(con.contador, j, 1);
                        }
                    }
                }
                break;
            case 3:
                simul.con3.Encolar(new Consola(simul.ID, 0, 3));
                simul.ID++;
                siz = simul.con3.size();
                if (siz <= 100) {
                    for (int j = 0; j < siz; j++) {
                        if (j < 100) {
                            con = simul.con3.primero();
                            simul.con3.DesEncolar();
                            simul.con3.Encolar(con);
                            ColaNivel3.setValueAt(con.ID, j, 0);
                            ColaNivel3.setValueAt(con.contador, j, 1);
                        }
                    }
                }
                break;
        }
    }//GEN-LAST:event_AgregarConsolBtnActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Interfaz().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Admintxt;
    private javax.swing.JButton AgregarConsolBtn;
    private javax.swing.JTable ColaNivel1;
    private javax.swing.JTable ColaNivel2;
    private javax.swing.JTable ColaNivel3;
    private javax.swing.JTable ColaREP;
    private javax.swing.JTextField ConsolRevis;
    private javax.swing.JTextField DayTxT;
    private javax.swing.JButton IniciarSimulBtn;
    private javax.swing.JButton SalirBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    // End of variables declaration//GEN-END:variables
}
