package proyecto.pkg2.so;

public class Cola<Consola> {

    private Nodo<Consola> primero;
    private Nodo<Consola> ultimo;
    private int tamaño;

    public Cola() {
        primero = null;
        ultimo = null;
        tamaño = 0;
    }

    public boolean IsEmpty() {
        return primero == null;
    }

    public int size() {
        return tamaño;
    }

    public Consola primero() {
        if (IsEmpty()) {
            return null;
        }
        return primero.getElemento();
    }

    public void Encolar(Consola element) {
        Nodo<Consola> aux = new Nodo(element, null);
        if (IsEmpty()) {
            primero = aux;
            ultimo = aux;
        } else {
            if (tamaño == 1) {
                primero.setSiguiente(aux);
            } else {
                ultimo.setSiguiente(aux);
            }
            ultimo = aux;
        }
        tamaño++;
    }

    public void DesEncolar() {
        Nodo<Consola> aux = primero.getSiguiente();
        primero = null;
        primero = aux;
        tamaño--;
        if (IsEmpty()) {
            ultimo = null;
        }
    }
}
