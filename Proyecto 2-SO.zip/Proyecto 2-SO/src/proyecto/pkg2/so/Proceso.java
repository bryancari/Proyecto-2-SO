package proyecto.pkg2.so;

import static java.lang.Thread.sleep;
import javax.swing.JTable;
import javax.swing.JTextField;

public class Proceso implements Runnable {

    Cola<Consola> con1;
    Cola<Consola> con2;
    Cola<Consola> con3;
    Cola<Consola> conR;
    JTable ColaNiv1;
    JTable ColaNiv2;
    JTable ColaNiv3;
    JTable ColaR;
    JTextField EstadoAdmin;
    JTextField EstadoRobot;
    JTextField Day;
    int ID;

    public Proceso(Cola<Consola> con1, Cola<Consola> con2, Cola<Consola> con3, Cola<Consola> conR,
            JTable ColaNiv1, JTable ColaNiv2, JTable ColaNiv3, JTable ColaR,
            JTextField EstadoAdmin, JTextField EstadoRobot, int ID, JTextField Day) {
        this.con1 = con1;
        this.con2 = con2;
        this.con3 = con3;
        this.ColaNiv1 = ColaNiv1;
        this.ColaNiv2 = ColaNiv2;
        this.ColaNiv3 = ColaNiv3;
        this.conR = conR;
        this.ColaR = ColaR;
        this.EstadoAdmin = EstadoAdmin;
        this.EstadoRobot = EstadoRobot;
        this.ID = ID;
        this.Day = Day;
    }

    public void Iniciar() {
        int prio = (int) (Math.random() * 3) + 1;
        Consola con;
        int siz;
        switch (prio) {
            case 1:
                con1.Encolar(new Consola(ID, 0, 1));
                ID++;
                siz = con1.size();
                for (int j = 0; j < siz; j++) {
                    if (j < 100) {
                        con = con1.primero();
                        con1.DesEncolar();
                        con1.Encolar(con);
                        ColaNiv1.setValueAt(con.ID, j, 0);
                        ColaNiv1.setValueAt(con.contador, j, 1);
                    }
                }
                break;
            case 2:
                con2.Encolar(new Consola(ID, 0, 2));
                ID++;
                siz = con2.size();
                for (int j = 0; j < siz; j++) {
                    if (j < 100) {
                        con = con2.primero();
                        con2.DesEncolar();
                        con2.Encolar(con);
                        ColaNiv2.setValueAt(con.ID, j, 0);
                        ColaNiv2.setValueAt(con.contador, j, 1);
                    }
                }
                break;
            case 3:
                con3.Encolar(new Consola(ID, 0, 3));
                ID++;
                siz = con3.size();
                for (int j = 0; j < siz; j++) {
                    if (j < 100) {
                        con = con3.primero();
                        con3.DesEncolar();
                        con3.Encolar(con);
                        ColaNiv3.setValueAt(con.ID, j, 0);
                        ColaNiv3.setValueAt(con.contador, j, 1);
                    }
                }
                break;
        }
    }

    public void ChequearContador(Cola<Consola> cola, JTable ColaN, Cola<Consola> cola2, JTable ColaN2) {
        Consola con;
        int siz, prio, siz2;
        siz = cola.size();
        for (int j = 0; j < siz; j++) {
            if (j < 100) {
                con = cola.primero();
                cola.DesEncolar();
                if (con.contador == 15) {
                    prio = con.Prioridad;
                    prio--;
                    con.setPrioridad(prio);
                    con.setContador(0);
                    cola2.Encolar(con);
                    siz2 = cola2.size();
                    for (int i = 0; i < siz2; i++) {
                        if (i < 100) {
                            con = cola2.primero();
                            cola2.DesEncolar();
                            cola2.Encolar(con);
                            ColaN2.setValueAt("", i, 0);
                            ColaN2.setValueAt("", i, 1);
                        }
                    }
                    ColaN.setValueAt("", j, 0);
                    ColaN.setValueAt("", j, 1);
                } else {
                    cola.Encolar(con);
                    ColaN.setValueAt("", j, 0);
                    ColaN.setValueAt("", j, 1);
                }
            }
        }
    }

    public void AumentarPrioridadREP() {
        if (conR.IsEmpty() == false) {
            Consola con;
            int prio;
            int siz = conR.size();
            if (siz <= 100) {
                for (int j = 0; j < siz; j++) {
                    if (j < 100) {
                        con = conR.primero();
                        conR.DesEncolar();
                        if (con.contador == 15) {
                            prio = con.Prioridad;
                            prio--;
                            if (prio != 0) {
                                con.setPrioridad(prio);
                                con.setContador(0);
                            }
                        }
                        conR.Encolar(con);
                        ColaR.setValueAt(con.ID, j, 0);
                        ColaR.setValueAt(con.Prioridad, j, 1);
                        ColaR.setValueAt(con.contador, j, 2);
                    }
                }
            }
        }
    }

    public void AumentarConTR(Cola<Consola> cola) {
        Consola con;
        int contador;
        if (cola.IsEmpty() == false) {
            for (int i = 0; i < cola.size(); i++) {
                if (i == cola.size() - 1) {
                    con = cola.primero();
                    cola.DesEncolar();
                    cola.Encolar(con);
                } else {
                    con = cola.primero();
                    contador = con.contador;
                    contador++;
                    con.setContador(contador);
                    cola.DesEncolar();
                    cola.Encolar(con);
                }
            }
        }
    }

    public void AumentarContador(Cola<Consola> cola) {
        Consola con;
        int contador;
        if (cola.IsEmpty() == false) {
            for (int i = 0; i < cola.size(); i++) {
                con = cola.primero();
                contador = con.contador;
                contador++;
                con.setContador(contador);
                cola.DesEncolar();
                cola.Encolar(con);
            }
        }
    }

    public void VolverCero(Cola<Consola> cola, JTable ColaN) {
        Consola con;
        int cuenta = 0;
        for (int j = 0; j < cola.size(); j++) {
            if (j < 100) {
                if (cuenta == 0) {
                    con = cola.primero();
                    con.setContador(0);
                    cola.DesEncolar();
                    cola.Encolar(con);
                    ColaN.setValueAt(con.ID, j, 0);
                    ColaN.setValueAt(0, j, 1);
                    cuenta++;
                } else {
                    con = cola.primero();
                    cola.DesEncolar();
                    cola.Encolar(con);
                    ColaN.setValueAt(con.ID, j, 0);
                    ColaN.setValueAt(con.contador, j, 1);
                }
            }
        }
    }

    public void Mostrar() {
        Consola con;
        int siz, sizR;
        siz = con1.size();
        for (int j = 0; j < siz; j++) {
            if (j < 100) {
                con = con1.primero();
                con1.DesEncolar();
                con1.Encolar(con);
                ColaNiv1.setValueAt(con.ID, j, 0);
                ColaNiv1.setValueAt(con.contador, j, 1);
            }
        }
        siz = con2.size();
        for (int j = 0; j < siz; j++) {
            if (j < 100) {
                con = con2.primero();
                con2.DesEncolar();
                con2.Encolar(con);
                ColaNiv2.setValueAt(con.ID, j, 0);
                ColaNiv2.setValueAt(con.contador, j, 1);
            }
        }
        siz = con3.size();
        for (int j = 0; j < siz; j++) {
            if (j < 100) {
                con = con3.primero();
                con3.DesEncolar();
                con3.Encolar(con);
                ColaNiv3.setValueAt(con.ID, j, 0);
                ColaNiv3.setValueAt(con.contador, j, 1);
            }
        }
        sizR = conR.size();
        if (sizR <= 100) {
            for (int j = 0; j < sizR; j++) {
                if (j < 100) {
                    con = conR.primero();
                    conR.DesEncolar();
                    conR.Encolar(con);
                    ColaR.setValueAt(con.ID, j, 0);
                    ColaR.setValueAt(con.Prioridad, j, 1);
                    ColaR.setValueAt(con.contador, j, 2);
                }
            }
        }
    }

    public void ConsolaRep() {
        int destino = (int) (Math.random() * 20) + 1;
        int prio, siz2;
        if (conR.IsEmpty() == false) {
            if (destino <= 9) {
                Consola con;
                con = conR.primero();
                conR.DesEncolar();
                prio = con.Prioridad;
                switch (prio) {
                    case 1:
                        con1.Encolar(con);
                        siz2 = con1.size();
                        for (int j = 0; j < siz2; j++) {
                            if (j < 100) {
                                con = con1.primero();
                                con1.DesEncolar();
                                con1.Encolar(con);
                                ColaNiv1.setValueAt(con.ID, j, 0);
                                ColaNiv1.setValueAt(con.contador, j, 1);
                            }
                        }
                        break;
                    case 2:
                        con2.Encolar(con);
                        siz2 = con2.size();
                        for (int j = 0; j < siz2; j++) {
                            if (j < 100) {
                                con = con2.primero();
                                con2.DesEncolar();
                                con2.Encolar(con);
                                ColaNiv2.setValueAt(con.ID, j, 0);
                                ColaNiv2.setValueAt(con.contador, j, 1);
                            }
                        }
                        break;
                    case 3:
                        con3.Encolar(con);
                        siz2 = con3.size();
                        for (int j = 0; j < siz2; j++) {
                            if (j < 100) {
                                con = con3.primero();
                                con3.DesEncolar();
                                con3.Encolar(con);
                                ColaNiv3.setValueAt(con.ID, j, 0);
                                ColaNiv3.setValueAt(con.contador, j, 1);
                            }
                        }
                        break;
                }
                int siz = conR.size();
                if (siz <= 100 && siz != 0) {
                    for (int j = 0; j < siz + 1; j++) {
                        if (j < 100 && j != siz) {
                            con = conR.primero();
                            conR.DesEncolar();
                            ColaR.setValueAt(con.ID, j, 0);
                            ColaR.setValueAt(con.Prioridad, j, 1);
                            ColaR.setValueAt(con.contador, j, 2);
                        } else if (j == siz) {
                            ColaR.setValueAt("", j, 0);
                            ColaR.setValueAt("", j, 1);
                            ColaR.setValueAt("", j, 2);
                        }
                    }
                } else if (siz == 0) {
                    ColaR.setValueAt("", 0, 0);
                    ColaR.setValueAt("", 0, 1);
                    ColaR.setValueAt("", 0, 2);
                }
            }
        }
    }

    public void MejoraCola(Cola<Consola> cola, JTable ColaN) {
        Consola con;
        int siz, sizR;
        con = cola.primero();
        cola.DesEncolar();
        conR.Encolar(con);
        siz = cola.size();
        if (siz <= 100 && siz != 0) {
            for (int j = 0; j < siz + 1; j++) {
                if (j < 100 && j != siz) {
                    con = cola.primero();
                    cola.DesEncolar();
                    cola.Encolar(con);
                    ColaN.setValueAt(con.ID, j, 0);
                    ColaN.setValueAt(con.contador, j, 1);
                } else if (j == siz) {
                    ColaN.setValueAt("", j, 0);
                    ColaN.setValueAt("", j, 1);
                }
            }
        } else if (siz == 0) {
            ColaN.setValueAt("", 0, 0);
            ColaN.setValueAt("", 0, 1);
        }
        sizR = conR.size();
        if (sizR <= 100) {
            for (int j = 0; j < sizR; j++) {
                if (j < 100) {
                    con = conR.primero();
                    conR.DesEncolar();
                    conR.Encolar(con);
                    ColaR.setValueAt(con.ID, j, 0);
                    ColaR.setValueAt(con.Prioridad, j, 1);
                    ColaR.setValueAt(con.contador, j, 2);
                }
            }
        }
    }

    public void VolverCola(Cola<Consola> cola, JTable ColaN) {
        Consola con;
        int siz;
        con = cola.primero();
        cola.DesEncolar();
        cola.Encolar(con);
        siz = cola.size();
        if (siz <= 100) {
            for (int j = 0; j < siz; j++) {
                if (j < 100) {
                    con = cola.primero();
                    cola.DesEncolar();
                    cola.Encolar(con);
                    ColaN.setValueAt(con.ID, j, 0);
                    ColaN.setValueAt(con.contador, j, 1);
                }
            }
        }
    }

    public void SalirCola(Cola<Consola> cola, JTable ColaN) {
        Consola con;
        int siz;
        cola.DesEncolar();
        siz = cola.size();
        if (siz <= 100 && siz != 0) {
            for (int j = 0; j < siz + 1; j++) {
                if (j < 100 && j != siz) {
                    con = cola.primero();
                    cola.DesEncolar();
                    cola.Encolar(con);
                    ColaN.setValueAt(con.ID, j, 0);
                    ColaN.setValueAt(con.contador, j, 1);
                } else if (j == siz) {
                    ColaN.setValueAt("", j, 0);
                    ColaN.setValueAt("", j, 1);
                }
            }
        } else if (siz == 0) {
            ColaN.setValueAt("", 0, 0);
            ColaN.setValueAt("", 0, 1);
        }
    }

    @Override
    public void run() {
        Iniciar();
        int cuenta = 0;
        int destiny;
        while (true) {
            if (con1.IsEmpty() == false) {
                VolverCero(con1, ColaNiv1);
                EstadoRobot.setText("" + con1.primero().ID);
                try {
                    sleep(1000 * 7);
                } catch (Exception e) {
                }
                EstadoAdmin.setText("Actualizando Colas");
                EstadoRobot.setText("--------");
                try {
                    sleep(1000 * 3);
                } catch (Exception e) {
                }
                destiny = (int) (Math.random() * 10) + 1;
                if (destiny <= 3) {
                    SalirCola(con1, ColaNiv1);
                    AumentarContador(con1);
                    AumentarContador(conR);
                    AumentarContador(con2);
                    AumentarContador(con3);
                    ConsolaRep();
                } else if (destiny >= 4 && destiny <= 8) {
                    VolverCola(con1, ColaNiv1);
                    AumentarConTR(con1);
                    AumentarContador(conR);
                    AumentarContador(con2);
                    AumentarContador(con3);
                    ConsolaRep();
                } else if (destiny >= 9) {
                    AumentarConTR(conR);
                    ConsolaRep();
                    MejoraCola(con1, ColaNiv1);
                    AumentarContador(con1);
                    AumentarContador(con2);
                    AumentarContador(con3);
                }
                ChequearContador(con3, ColaNiv3, con2, ColaNiv2);
                ChequearContador(con2, ColaNiv2, con1, ColaNiv1);
                AumentarPrioridadREP();
                EstadoAdmin.setText("Esperando");
                Mostrar();
            } else if (con2.IsEmpty() == false) {
                VolverCero(con2, ColaNiv2);
                EstadoRobot.setText("" + con2.primero().ID);
                try {
                    sleep(1000 * 7);
                } catch (Exception e) {
                }
                EstadoAdmin.setText("Actualizando Colas");
                EstadoRobot.setText("--------");
                try {
                    sleep(1000 * 3);
                } catch (Exception e) {
                }
                destiny = (int) (Math.random() * 10) + 1;
                if (destiny <= 3) {
                    SalirCola(con2, ColaNiv2);
                    AumentarContador(con1);
                    AumentarContador(conR);
                    AumentarContador(con2);
                    AumentarContador(con3);
                    ConsolaRep();
                } else if (destiny >= 4 && destiny <= 8) {
                    VolverCola(con2, ColaNiv2);
                    AumentarContador(con1);
                    AumentarContador(conR);
                    AumentarConTR(con2);
                    AumentarContador(con3);
                    ConsolaRep();
                } else if (destiny >= 9) {
                    AumentarConTR(conR);
                    ConsolaRep();
                    MejoraCola(con2, ColaNiv2);
                    AumentarContador(con1);
                    AumentarContador(con2);
                    AumentarContador(con3);
                }
                ChequearContador(con3, ColaNiv3, con2, ColaNiv2);
                ChequearContador(con2, ColaNiv2, con1, ColaNiv1);
                AumentarPrioridadREP();
                EstadoAdmin.setText("Esperando");
                Mostrar();
            } else if (con3.IsEmpty() == false) {
                VolverCero(con3, ColaNiv3);
                EstadoRobot.setText("" + con3.primero().ID);
                try {
                    sleep(1000 * 7);
                } catch (Exception e) {
                }
                EstadoAdmin.setText("Actualizando Colas");
                EstadoRobot.setText("--------");
                try {
                    sleep(1000 * 3);
                } catch (Exception e) {
                }
                destiny = (int) (Math.random() * 10) + 1;
                if (destiny <= 3) {
                    SalirCola(con3, ColaNiv3);
                    AumentarContador(con1);
                    AumentarContador(conR);
                    AumentarContador(con2);
                    AumentarContador(con3);
                    ConsolaRep();
                } else if (destiny >= 4 && destiny <= 8) {
                    VolverCola(con3, ColaNiv3);
                    AumentarContador(con1);
                    AumentarContador(conR);
                    AumentarConTR(con3);
                    AumentarContador(con2);
                    ConsolaRep();
                } else if (destiny >= 9) {
                    AumentarConTR(conR);
                    ConsolaRep();
                    MejoraCola(con3, ColaNiv3);
                    AumentarContador(con1);
                    AumentarContador(con2);
                    AumentarContador(con3);
                }
                ChequearContador(con3, ColaNiv3, con2, ColaNiv2);
                ChequearContador(con2, ColaNiv2, con1, ColaNiv1);
                AumentarPrioridadREP();
                EstadoAdmin.setText("Esperando");
                Mostrar();
            } else if (conR.IsEmpty() == false) {
                EstadoAdmin.setText("Actualizando Cola de Mejoras");
                EstadoRobot.setText("--------");
                try {
                    sleep(1000 * 3);
                } catch (Exception e) {
                }
                ConsolaRep();
                cuenta--;
                EstadoAdmin.setText("Esperando");
            } else {
                EstadoAdmin.setText("Agregando Consola");
                try {
                    sleep(1000 * 2);
                } catch (Exception e) {
                }
                Iniciar();
                EstadoAdmin.setText("Esperando");
                cuenta--;
            }
            cuenta++;
            if (cuenta == 2) {
                int agregar = (int) (Math.random() * 10) + 1;
                if (agregar <= 7) {
                    EstadoAdmin.setText("Agregando Consola");
                    try {
                        sleep(1000 * 2);
                    } catch (Exception e) {
                    }
                    Iniciar();
                    EstadoAdmin.setText("Esperando");
                }
                cuenta = 0;
            }
            String day = Day.getText();
            int dia = Integer.parseInt(day);
            dia++;
            String num = "" + dia;
            Day.setText(num);
        }

    }

    public void start() {
        new Thread(this).start();
    }
}