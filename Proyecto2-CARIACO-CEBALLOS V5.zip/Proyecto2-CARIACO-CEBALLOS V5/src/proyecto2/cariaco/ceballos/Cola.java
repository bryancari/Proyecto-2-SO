package proyecto2.cariaco.ceballos;

import javax.swing.JOptionPane;

/**
 * Clase que crea las distintas colas que se usarán en el proyecto
 *
 * @author Juan Ceballos
 */
public class Cola {

    private int longitud;
    private Proceso cola;
    private Proceso cabecera;

    public Cola() {
        this.longitud = 0;
        this.cola = this.cabecera = null;
    }

    /**
     * @return the longitud
     */
    public int getLongitud() {
        return longitud;
    }

    /**
     * @param longitud the longitud to set
     */
    public void setLongitud(int longitud) {
        this.longitud = longitud;
    }

    /**
     * @return the cola
     */
    public Proceso getCola() {
        return cola;
    }

    /**
     * @param cola the cola to set
     */
    public void setCola(Proceso cola) {
        this.cola = cola;
    }

    /**
     * @return the cabecera
     */
    public Proceso getCabecera() {
        return cabecera;
    }

    /**
     * @param cabecera the cabecera to set
     */
    public void setCabecera(Proceso cabecera) {
        this.cabecera = cabecera;
    }

    /**
     *
     * @return El valor de longitud como 0
     */
    public boolean esVacia() {
        return longitud == 0;
    }

    /**
     * @param nuevo es el Proceso que ya fue instanciado y está listo para ser agregado a la cola
     */
    public void encolar(Proceso nuevo) {
        if (esVacia()) {
            cabecera = cola = nuevo;
        } else {
            Proceso aux = cola;
            aux.setNext(nuevo);
            cola = aux.getNext();
        }
        longitud++;
    }

    /**
     * Desencola regresando el proceso para que, en caso de que ocurra un empate o no se pueda llevar a cabo la batalla, este se pueda agregar a otra cola
     *
     * @return Regresa el proceso que se va a borrar al colocar su próximo set en null
     */
    public Proceso desencolar() {
        if (esVacia()) {
            return null;
        } else {
            Proceso aux = cabecera;
            cabecera = aux.getNext();
            longitud--;
            aux.setNext(null);
            return aux;
        }
    }

    /**
     * Función que sirve para retornar un personaje que completó los ocho
     * ciclos para poder ser ascendido de prioridad. Por lo cual, antes de ser ascendido, se le reinicia en cero el
     * contador antes de enviarlo
     *
     * @param caso si el caso es igual a 1 entonces cumplió los ocho ciclos, si es otro caso es porque se está
     * buscando según su prioridad para competir
     * @param prioridad es el nivel del personaje que se busca para que compita
     * @return un personaje o proceso que va a ser ascendido en prioridad
     */
    public Proceso quitarCondicion(int caso, int prioridad) {
        if (caso == 1) {
            if (esVacia()) {
                return null;
            } else {

                if (cabecera.getContador() == 8) {
                    Proceso aux = cabecera;
                    cabecera = aux.getNext();
                    longitud--;
                    aux.setContador(0);
                    return aux;
                } else {
                    Proceso auxAnterior = cabecera;
                    Proceso auxActual = cabecera.getNext();
                    int auxNum = 0;
                    while (auxNum < longitud) {
                        if (auxActual.getContador() == 8) {
                            auxAnterior.setNext(auxActual.getNext());
                            longitud--;
                            auxActual.setContador(0);
                            return auxActual;
                        }
                        auxAnterior = auxActual;
                        auxActual = auxActual.getNext();
                        auxNum++;
                    }
                }
                return null;
            }
        } else {
            if (esVacia()) {
                return null;
            } else {
                if (cabecera.getPrioridad() == prioridad) {
                    Proceso aux = cabecera;
                    cabecera = aux.getNext();
                    longitud--;
                    aux.setContador(0);
                    return aux;
                } else {
                    Proceso auxAnterior = cabecera;
                    Proceso auxActual = cabecera.getNext();
                    int auxNum = 0;
                    while (auxNum < longitud) {
                        if (auxActual.getPrioridad() == prioridad) {
                            auxAnterior.setNext(auxActual.getNext());
                            longitud--;
                            auxActual.setContador(0);
                            return auxActual;
                        }
                        auxAnterior = auxActual;
                        auxActual = auxActual.getNext();
                        auxNum++;
                    }
                }
                return null;
            }
        }
    }

    /**
     * Función que se encarga de sacar un proceso de una cola de acuerdo al nivel de prioridad que tenga
     *
     * @param prioridad el nivel de prioridad que se requiere
     * @return
     */
    public Proceso quitarPorPrioridad(int prioridad) {
        if (esVacia()) {
            return null;
        } else {
            if (cabecera.getPrioridad() == prioridad) {
                Proceso aux = cabecera;
                cabecera = aux.getNext();
                longitud--;
                aux.setContador(0);
                return aux;
            } else {
                Proceso auxAnterior = cabecera;
                Proceso auxActual = cabecera.getNext();
                int auxNum = 0;
                while (auxNum < longitud) {
                    if (auxActual.getPrioridad() == prioridad) {
                        auxAnterior.setNext(auxActual.getNext());
                        longitud--;
                        auxActual.setContador(0);
                        return auxActual;
                    }
                    auxAnterior = auxActual;
                    auxActual = auxActual.getNext();
                    auxNum++;
                }
            }
            return null;
        }
    }

    /**
     * Procedimiento que se encarga de aumentar en 1 el contador de cada personaje de la cola
     */
    public void aumentarContador() {
        if (esVacia()) {
            JOptionPane.showMessageDialog(null, "No hay objetos en la cola");
        } else {
            Proceso aux = cabecera;
            int auxLong = 0;
            while (auxLong < longitud) {
                int auxNum = aux.getContador();
                auxNum++;
                aux.setContador(auxNum);
                aux = aux.getNext();
                auxLong++;
            }
        }
    }

    /**
     * Función que se encarga de determinar la cantidad de personajes cuyo contador es igual a 8
     *
     * @return La cantidad de personajes cuyo contador es igual a 8
     */
    public int contarContadores() {
        if (esVacia()) {
            return 0;
        } else {
            int auxNumPrioridad = 0;
            Proceso aux = cabecera;
            int auxLong = 0;
            while (auxLong < longitud) {
                if (aux.getContador() == 8) {
                    auxNumPrioridad++;
                }
                aux = aux.getNext();
                auxLong++;
            }
            return auxNumPrioridad;
        }
    }

    /**
     *
     * @return Una cadena de string que contiene todos los ID de los procesos encolados en la cola correspondiente
     */
    public String imprimir() {
        String auxCola = "";
        if (esVacia()) {
            return "Vacía";
        } else {
            Proceso aux = cabecera;
            int auxLong = 0;
            while (auxLong < longitud) {
                auxCola += " --ID: " + aux.getId();
                aux = aux.getNext();
                auxLong++;
            }
        }
        return auxCola;
    }

}
