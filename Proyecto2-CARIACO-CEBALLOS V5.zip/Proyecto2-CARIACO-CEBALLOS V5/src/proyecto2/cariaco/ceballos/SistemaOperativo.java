package proyecto2.cariaco.ceballos;

import java.util.concurrent.Semaphore;

/**
 * Clase definida para cumplir el rol del sistema operativo y así organizar a los
 * personajes y a las colas
 *
 * @author Juan Ceballos
 */
public class SistemaOperativo extends Thread {

    private Cola nivel_1_N;
    private Cola nivel_2_N;
    private Cola nivel_3_N;
    private Cola refuerzo_N;
    private Cola nivel_1_C;
    private Cola nivel_2_C;
    private Cola nivel_3_C;
    private Cola refuerzo_C;
    private int identificador_C;
    private int identificador_N;
    private int ciclos;
    private Proceso capcom;
    private Proceso nintendo;
    private int ultimo_resultado;
    private Cola ganadores;
    private int ganadores_capcom;
    private int ganadores_nintendo;
    private final Semaphore sema;

    /**
     * Constructor del Sistema Operativo
     *
     * @param sema Semaforo que usa el procesador
     * @param inicial Número de personajes que se crearán al iniciar la simulación
     */
    public SistemaOperativo(Semaphore sema, int inicial) {
        this.sema = sema;
        this.ganadores = new Cola();
        this.nivel_1_N = new Cola();
        this.nivel_2_N = new Cola();
        this.nivel_3_N = new Cola();
        this.refuerzo_N = new Cola();
        this.nivel_1_C = new Cola();
        this.nivel_2_C = new Cola();
        this.nivel_3_C = new Cola();
        this.refuerzo_C = new Cola();
        this.identificador_C = 1;
        this.identificador_N = 1;
        this.ciclos = 0;
        this.ganadores_capcom = 0;
        this.ganadores_nintendo = 0;

        int aux = inicial;
        while (aux != 0) {
            this.crearPersonaje("C");
            this.crearPersonaje("N");
            aux--;
        }
    }

    /**
     * Procedimiento que se encarga de crear un personaje nuevo, y la validación del ID se
     * hace mediante un contador para cada empresa que tiene como atributos la
     * clase.
     *
     * @param empresa Un string igual a C o N para identificar la empresa a la que pertenecerá el personaje
     */
    public void crearPersonaje(String empresa) {
        int auxHabilidad = (int) (Math.floor(Math.random() * 100));
        int auxVida = (int) (Math.floor(Math.random() * 100));
        int auxFuerza = (int) (Math.floor(Math.random() * 100));
        int auxAgilidad = (int) (Math.floor(Math.random() * 100));

        int auxPrioridad = 0;

        int numHabilidad = 0;
        int numVida = 0;
        int numFuerza = 0;
        int numAgilidad = 0;

        if (auxHabilidad >= 40) {
            auxPrioridad++;
            numHabilidad++;
        }
        if (auxVida >= 30) {
            auxPrioridad++;
            numVida++;
        }
        if (auxFuerza >= 50) {
            auxPrioridad++;
            numFuerza++;
        }
        if (auxAgilidad >= 60) {
            auxPrioridad++;
            numFuerza++;
        }
        switch (auxPrioridad) {
    
            case 0:

                auxHabilidad = (int) (Math.floor(Math.random() * (44 - 5 + 1) + 5));
                auxVida = (int) (Math.floor(Math.random() * (399 - 100 + 1) + 100));
                auxFuerza = (int) (Math.floor(Math.random() * (2199 - 500 + 1) + 500));
                auxAgilidad = (int) (Math.floor(Math.random() * (399 - 100 + 1) + 100));

                auxPrioridad = 3;
                break;
            case 1:
            case 2:
                if (numHabilidad == 1) {
                    auxHabilidad = (int) (Math.floor(Math.random() * (100 - 75 + 1) + 75));
                } else {
                    auxHabilidad = (int) (Math.floor(Math.random() * (74 - 45 + 1) + 45));
                }

                if (numVida == 1) {
                    auxVida = (int) (Math.floor(Math.random() * (1000 - 700 + 1) + 700));
                } else {
                    auxVida = (int) (Math.floor(Math.random() * (699 - 400 + 1) + 400));
                }
                if (numFuerza == 1) {
                    auxFuerza = (int) (Math.floor(Math.random() * (5000 - 3800 + 1) + 3800));
                } else {
                    auxFuerza = (int) (Math.floor(Math.random() * (3799 - 2200 + 1) + 2200));
                }
                if (numAgilidad == 1) {
                    auxAgilidad = (int) (Math.floor(Math.random() * (800 - 650 + 1) + 650));
                } else {
                    auxAgilidad = (int) (Math.floor(Math.random() * (649 - 400 + 1) + 400));
                }
                auxPrioridad = 2;
                break;
            default:
                if (numHabilidad == 1) {
                    auxHabilidad = (int) (Math.floor(Math.random() * (100 - 75 + 1) + 75));
                } else {
                    auxHabilidad = (int) (Math.floor(Math.random() * (74 - 45 + 1) + 45));
                }

                if (numVida == 1) {
                    auxVida = (int) (Math.floor(Math.random() * (1000 - 700 + 1) + 700));
                } else {
                    auxVida = (int) (Math.floor(Math.random() * (699 - 400 + 1) + 400));
                }
                if (numFuerza == 1) {
                    auxFuerza = (int) (Math.floor(Math.random() * (5000 - 3800 + 1) + 3800));
                } else {
                    auxFuerza = (int) (Math.floor(Math.random() * (3799 - 2200 + 1) + 2200));
                }
                if (numAgilidad == 1) {
                    auxAgilidad = (int) (Math.floor(Math.random() * (800 - 650 + 1) + 650));
                } else {
                    auxAgilidad = (int) (Math.floor(Math.random() * (649 - 400 + 1) + 400));
                }
                auxPrioridad = 1;
                break;
        }

        if ("C".equals(empresa)) {
            Proceso nProcesoC = new Proceso("C-" + String.valueOf(getIdentificador_C()), auxPrioridad, auxHabilidad, auxVida, auxFuerza, auxAgilidad);
            setIdentificador_C(getIdentificador_C() + 1);
            switch (auxPrioridad) {
                case 1:
                    getNivel_1_C().encolar(nProcesoC);
                    break;
                case 2:
                    getNivel_2_C().encolar(nProcesoC);
                    break;
                default:
                    getNivel_3_C().encolar(nProcesoC);
                    break;
            }
        } else {
            Proceso nProcesoN = new Proceso("C-" + String.valueOf(getIdentificador_C()), auxPrioridad, auxHabilidad, auxVida, auxFuerza, auxAgilidad);
            setIdentificador_N(getIdentificador_N() + 1);
            switch (auxPrioridad) {
                case 1:
                    getNivel_1_N().encolar(nProcesoN);
                    break;
                case 2:
                    getNivel_2_N().encolar(nProcesoN);
                    break;
                default:
                    getNivel_3_N().encolar(nProcesoN);
                    break;
            }
        }
    }

    /**
     * Procedimiento que sirve para cambiar a un proceso de cola si cumplió con los 8
     * ciclos.
     *
     * @param colaNueva Cola de prioridad a la cual se le van a agregar personajes
     * @param colaVieja Cola que se va a revisar para determinar los personajes que
     * cumplieron los ocho ciclos
     * @param prioridadAux número de elementos originales en la cola vieja a la
     * cual se le van a quitar los personajes que serán ascendidos de prioridad
     */
    public void cambiosPrioridad(Cola colaNueva, Cola colaVieja, int prioridadAux) {
        int aux = prioridadAux;
        while (aux != 0) {
            Proceso auxProceso = colaVieja.quitarCondicion(1, 0);
            if (auxProceso != null) {
                colaNueva.encolar(auxProceso);
            }
            aux--;
        }
    }

    /**
     * Procedimiento que se encarga de crear nuevos personajes cada dos ciclos
     *
     */
    public void crearPersonajeAleatorio() {
        int auxProba = (int) (Math.floor(Math.random() * 100));
        if (auxProba <= 80) {
            crearPersonaje("N");
            crearPersonaje("C");
        }

    }

    /**
     * Procedimiento que se utiliza para guardar los cambios que ocurrieron según los resultados dados en la última
     * batalla
     */
    public void modificarResultados() {
        switch (ultimo_resultado) {
            case 1:
                ganadores.encolar(capcom);
                ganadores_capcom++;
                break;
            case 2:
                ganadores.encolar(nintendo);
                ganadores_nintendo++;
                break;
            case 3:
                nivel_1_N.encolar(nintendo);
                nivel_1_C.encolar(capcom);
                break;
            default:
                refuerzo_C.encolar(capcom);
                refuerzo_N.encolar(nintendo);
                break;
        }
    }

    /**
     * Función que se encarga de retornar quien va a representar en el
     * combate actual a cada empresa
     *
     * @param empresa Identificador que representará el origen del personaje, peude ser N de Nintendo o C de Capcom
     * @return retorna el personaje que va a representar a una de las compañías
     */
    public Proceso escogerCompetidorEmpresa(String empresa) {
        Proceso aux = escogerCompetidorTipo(empresa, 1);
        if (aux == null) {
            aux = escogerCompetidorTipo(empresa, 2);
            if (aux == null) {
                aux = escogerCompetidorTipo(empresa, 3);
                if (aux == null) {
                    System.out.println("TODO MAL");
                    return null;
                } else {
                    return aux;
                }
            } else {
                return aux;
            }
        } else {
            return aux;
        }
    }

    /**
     * Función que se encarga de buscar en cada cola de cada empresa de acuerdo a la prioridad que
     * se esté buscando
     *
     * @param empresa String para poder determinar la compañía en la cual se van a revisar las colas 
     * @param prioridad Es el nivel del jugador que se esté buscando ya sea
     * nivel 1, 2 o 3
     * @return un proceso o null, si es null es porque ya todos los personajes salieron de todas las colas
     */
    public Proceso escogerCompetidorTipo(String empresa, int prioridad) {
        if ("N".equals(empresa)) {
            Proceso aux = nivel_1_N.quitarCondicion(2, prioridad);
            if (aux == null) {
                aux = nivel_2_N.quitarCondicion(2, prioridad);
                if (aux == null) {
                    aux = nivel_3_N.quitarCondicion(2, prioridad);
                    if (aux == null) {
                        return null;
                    } else {
                        return aux;
                    }
                } else {
                    return aux;
                }
            } else {
                return aux;
            }
        } else {
            Proceso aux = nivel_1_C.quitarCondicion(2, prioridad);
            if (aux == null) {
                aux = nivel_2_C.quitarCondicion(2, prioridad);
                if (aux == null) {
                    aux = nivel_3_C.quitarCondicion(2, prioridad);
                    if (aux == null) {
                        return null;
                    } else {
                        return aux;
                    }
                } else {
                    return aux;
                }
            } else {
                return aux;
            }
        }
    }

    /**
     * Procedimiento que se encarga de revisar si un personaje puede salir de la cola de refuerzo o no
     *
     * @param destino es la cola de nivel 1 a la cual se moverá el personaje en
     * caso de cumplir el porcentaje
     * @param refuerzoCola es la cola de refuerzo de la cual se saca el
     * personaje que podrá o no ser cambiado de cola
     * @param auxSalir probabilidad de que salgan
     */
    public void cambioRefuerzo(Cola destino, Cola refuerzoCola, int auxSalir) {
        if (!refuerzoCola.esVacia()) {
            Proceso auxProceso = refuerzoCola.desencolar();
            if (auxSalir >= 60) {
                destino.encolar(auxProceso);
            } else {
                refuerzoCola.encolar(auxProceso);
            }
        }

    }

    /**
     * Procedimiento utilizado para mover a los personajes que cumplan el ciclo a la siguiente
     * prioridad tanto para la empresa de Nintendo como la de Capcom
     */
    public void cambiosPrioridadGeneral() {
        int auxCola2N = getNivel_2_N().contarContadores();
        cambiosPrioridad(getNivel_1_N(), getNivel_2_N(), auxCola2N);

        int auxCola3N = getNivel_3_N().contarContadores();
        cambiosPrioridad(getNivel_2_N(), getNivel_3_N(), auxCola3N);

        int auxCola2C = getNivel_2_C().contarContadores();
        cambiosPrioridad(getNivel_1_C(), getNivel_2_C(), auxCola2C);

        int auxCola3C = getNivel_3_C().contarContadores();
        cambiosPrioridad(getNivel_2_C(), getNivel_3_C(), auxCola3C);

        int auxSalir = (int) (Math.floor(Math.random() * 100));
        cambioRefuerzo(getNivel_1_C(), getRefuerzo_C(), auxSalir);
        cambioRefuerzo(getNivel_1_N(), getRefuerzo_N(), auxSalir);
    }

    /**
     * Procedimiento que se encarga de incrementar los contadores de los personajes que se encuentran en las colas de
     * nivel 2 y 3 tanto para la empresa de Nintendo como para la de Capcom
     */
    public void aumentoContadores() {
        getNivel_2_N().aumentarContador();
        getNivel_3_N().aumentarContador();
        getNivel_2_C().aumentarContador();
        getNivel_3_C().aumentarContador();
    }

    /**
     * Procedimiento que se encarga de imprimir todas las colas que tiene cada compañía
     */
    public void imprimirColas() {
        System.out.println("");
        System.out.println("Cola Nintendo Prioridad 1: ");
        getNivel_1_N().imprimir();
        System.out.println("");
        System.out.println("Cola Nintendo Prioridad 2: ");
        getNivel_2_N().imprimir();
        System.out.println("");
        System.out.println("Cola Nintendo Prioridad 3: ");
        getNivel_3_N().imprimir();
        System.out.println("");
        System.out.println("Cola Capcom Prioridad 1: ");
        getNivel_1_C().imprimir();
        System.out.println("");
        System.out.println("Cola Capcom Prioridad 2: ");
        getNivel_2_C().imprimir();
        System.out.println("");
        System.out.println("Cola Capcom Prioridad 3: ");
        getNivel_3_C().imprimir();
    }

    /**
     * @return the nivel_1_N
     */
    public Cola getNivel_1_N() {
        return nivel_1_N;
    }

    /**
     * @param nivel_1_N the nivel_1_N to set
     */
    public void setNivel_1_N(Cola nivel_1_N) {
        this.nivel_1_N = nivel_1_N;
    }

    /**
     * @return the nivel_2_N
     */
    public Cola getNivel_2_N() {
        return nivel_2_N;
    }

    /**
     * @param nivel_2_N the nivel_2_N to set
     */
    public void setNivel_2_N(Cola nivel_2_N) {
        this.nivel_2_N = nivel_2_N;
    }

    /**
     * @return the nivel_3_N
     */
    public Cola getNivel_3_N() {
        return nivel_3_N;
    }

    /**
     * @param nivel_3_N the nivel_3_N to set
     */
    public void setNivel_3_N(Cola nivel_3_N) {
        this.nivel_3_N = nivel_3_N;
    }

    /**
     * @return the refuerzo_N
     */
    public Cola getRefuerzo_N() {
        return refuerzo_N;
    }

    /**
     * @param refuerzo_N the refuerzo_N to set
     */
    public void setRefuerzo_N(Cola refuerzo_N) {
        this.refuerzo_N = refuerzo_N;
    }

    /**
     * @return the nivel_1_C
     */
    public Cola getNivel_1_C() {
        return nivel_1_C;
    }

    /**
     * @param nivel_1_C the nivel_1_C to set
     */
    public void setNivel_1_C(Cola nivel_1_C) {
        this.nivel_1_C = nivel_1_C;
    }

    /**
     * @return the nivel_2_C
     */
    public Cola getNivel_2_C() {
        return nivel_2_C;
    }

    /**
     * @param nivel_2_C the nivel_2_C to set
     */
    public void setNivel_2_C(Cola nivel_2_C) {
        this.nivel_2_C = nivel_2_C;
    }

    /**
     * @return the nivel_3_C
     */
    public Cola getNivel_3_C() {
        return nivel_3_C;
    }

    /**
     * @param nivel_3_C the nivel_3_C to set
     */
    public void setNivel_3_C(Cola nivel_3_C) {
        this.nivel_3_C = nivel_3_C;
    }

    /**
     * @return the refuerzo_C
     */
    public Cola getRefuerzo_C() {
        return refuerzo_C;
    }

    /**
     * @param refuerzo_C the refuerzo_C to set
     */
    public void setRefuerzo_C(Cola refuerzo_C) {
        this.refuerzo_C = refuerzo_C;
    }

    /**
     * @return the identificador_C
     */
    public int getIdentificador_C() {
        return identificador_C;
    }

    /**
     * @param identificador_C the identificador_C to set
     */
    public void setIdentificador_C(int identificador_C) {
        this.identificador_C = identificador_C;
    }

    /**
     * @return the identificador_N
     */
    public int getIdentificador_N() {
        return identificador_N;
    }

    /**
     * @param identificador_N the identificador_N to set
     */
    public void setIdentificador_N(int identificador_N) {
        this.identificador_N = identificador_N;
    }

    @Override
    public void run() {
        while (true) {
            try {
                sema.acquire();
                modificarResultados();
                aumentoContadores();
                cambiosPrioridadGeneral();
                if (ciclos == 1) {
                    crearPersonajeAleatorio();
                    ciclos--;
                } else {
                    ciclos++;
                }
                nintendo = escogerCompetidorEmpresa("N");
                capcom = escogerCompetidorEmpresa("C");
                sema.release();
            } catch (Exception e) {

            }
        }
    }

    /**
     * @return the capcom
     */
    public Proceso getCapcom() {
        return capcom;
    }

    /**
     * @param capcom the capcom to set
     */
    public void setCapcom(Proceso capcom) {
        this.capcom = capcom;
    }

    /**
     * @return the nintendo
     */
    public Proceso getNintendo() {
        return nintendo;
    }

    /**
     * @param nintendo the nintendo to set
     */
    public void setNintendo(Proceso nintendo) {
        this.nintendo = nintendo;
    }

    /**
     * @return the ultimo_resultado
     */
    public int getUltimo_resultado() {
        return ultimo_resultado;
    }

    /**
     * @param ultimo_resultado the ultimo_resultado to set
     */
    public void setUltimo_resultado(int ultimo_resultado) {
        this.ultimo_resultado = ultimo_resultado;
    }

    /**
     * @return the ganadores
     */
    public Cola getGanadores() {
        return ganadores;
    }

    /**
     * @param ganadores the ganadores to set
     */
    public void setGanadores(Cola ganadores) {
        this.ganadores = ganadores;
    }

    /**
     * @return the ganadores_capcom
     */
    public int getGanadores_capcom() {
        return ganadores_capcom;
    }

    /**
     * @param ganadores_capcom the ganadores_capcom to set
     */
    public void setGanadores_capcom(int ganadores_capcom) {
        this.ganadores_capcom = ganadores_capcom;
    }

    /**
     * @return the ganadores_nintendo
     */
    public int getGanadores_nintendo() {
        return ganadores_nintendo;
    }

    /**
     * @param ganadores_nintendo the ganadores_nintendo to set
     */
    public void setGanadores_nintendo(int ganadores_nintendo) {
        this.ganadores_nintendo = ganadores_nintendo;
    }
}
