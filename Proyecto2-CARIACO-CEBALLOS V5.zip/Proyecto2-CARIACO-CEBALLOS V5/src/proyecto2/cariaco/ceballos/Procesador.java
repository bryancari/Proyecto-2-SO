package proyecto2.cariaco.ceballos;

import java.util.concurrent.Semaphore;

/**
 * Clase definida para el procesador el cual lleva a cabo los enfrentamientos y
 * arroja resultados que utilizará el SO para saber que acción realizar
 *
 * @author Juan Ceballos
 */
public class Procesador extends Thread {

    private int tiempo;
    private String estado_actual;
    private Proceso capcom;
    private Proceso nintendo;
    private int ultimo_resultado;
    private final Semaphore sema;

    public Procesador(Semaphore sema, int tiempo) {
        this.sema = sema;
        this.tiempo = tiempo;
        this.estado_actual = "Esperando";
    }

    /**
     * Procedimiento del rol que cumple el procesador
     *
     * @param capcom Posible personaje de Capcom
     * @param nintendo Posible personaje de Nintendo
     */
    public void escenarioEscogido(Proceso capcom, Proceso nintendo) {
        int auxProba = (int) (Math.floor(Math.random() * 100));
        if (auxProba >= 0 && auxProba < 40) {
            Proceso auxProceso = combate(capcom, nintendo);
            if (auxProceso == capcom) {
                ultimo_resultado = 1; //Caso en el que el personaje de Capcom ganó el combate 
            } else {
                ultimo_resultado = 2; //Caso en el que el personaje de Nintendo ganó el combate 
            }
        } else if (auxProba >= 40 && auxProba < 67) {
            ultimo_resultado = 3; //Caso en el que hubo un empate
        } else {
            ultimo_resultado = 4; //Caso en el que no se llevó a cabo el combate
        }
    }

    /**
     * Función que se encarga de realizar el combate, por medio de cada ítem que utiliza probabilidades si llega
     * a suceder que tengan distinto nivel, es decir, que llegan a ser de
     * distintos niveles (Poco probable, pero nunca imposible). Existirá un factor
     * de ayuda al del menor nivel basado en la suerte, 35% de suerte si tienen
     * dos niveles de diferencia y 25% de suerte si tienen un nivel de
     * diferencia, en el caso en el que estén en el mismo nivel, no hay suerte
     *
     * @param capcom Personaje de Capcom
     * @param nintendo Personaje de Nintendo
     * @return retorna el personaje que ganó el duelo
     */
    public Proceso combate(Proceso capcom, Proceso nintendo) {
        int puntosCapcom = 0;
        int puntosNintendo = 0;        

        if (capcom.getAgilidad() > nintendo.getAgilidad()) {            
            puntosCapcom++;
        } else if (capcom.getAgilidad() == nintendo.getAgilidad()) {
            puntosCapcom++;
            puntosNintendo++;
        } else {            
            puntosNintendo++;
        }

        if (capcom.getFuerza() > nintendo.getFuerza()) {            
            puntosCapcom++;
        } else if (capcom.getFuerza() == nintendo.getFuerza()) {
            puntosCapcom++;
            puntosNintendo++;
        } else {            
            puntosNintendo++;
        }

        if (capcom.getHabilidad() > nintendo.getHabilidad()) {  
            puntosCapcom++;
        } else if (capcom.getHabilidad() == nintendo.getHabilidad()) {
            puntosCapcom++;
            puntosNintendo++;
        } else {            
            puntosNintendo++;
        }

        if (capcom.getVida() > nintendo.getVida()) {            
            puntosCapcom++;
        } else if (capcom.getVida() == nintendo.getVida()) {
            puntosCapcom++;
            puntosNintendo++;
        } else {            
            puntosNintendo++;
        }

        if (puntosCapcom > puntosNintendo) {
            return capcom; //Caso en el que gana Capcom
        } else if (puntosCapcom == puntosNintendo) {
            int auxSuerte = (int) (Math.floor(Math.random() * (2 - 1 + 1) + 1));
            if (auxSuerte == 1) {
                return capcom; //Caso en el que gana Capcom por suerte
            } else {
                return nintendo; //Caso en el que gana Nintendo por suerte
            }

        } else {
            return nintendo; //Caso en el que gana Nintendo
        }
    }

    /**
     * @return the tiempo
     */
    public int getTiempo() {
        return tiempo;
    }

    /**
     * @param tiempo the tiempo to set
     */
    public void setTiempo(int tiempo) {
        this.tiempo = tiempo;
    }

    /**
     * @return the estado_actual
     */
    public String getEstado_actual() {
        return estado_actual;
    }

    /**
     * @param estado_actual the estado_actual to set
     */
    public void setEstado_actual(String estado_actual) {
        this.estado_actual = estado_actual;
    }

    @Override
    public void run() {
        while (true) {
            try {
                sema.acquire();
                escenarioEscogido(capcom, nintendo);
                sleep(tiempo * 1000);
                sema.release();
            } catch (Exception e) {

            }
        }
    }

    /**
     * @return the capcom
     */
    public Proceso getCapcom() {
        return capcom;
    }

    /**
     * @param capcom the capcom to set
     */
    public void setCapcom(Proceso capcom) {
        this.capcom = capcom;
    }

    /**
     * @return the nintendo
     */
    public Proceso getNintendo() {
        return nintendo;
    }

    /**
     * @param nintendo the nintendo to set
     */
    public void setNintendo(Proceso nintendo) {
        this.nintendo = nintendo;
    }

    /**
     * @return the ultimo_resultado
     */
    public int getUltimo_resultado() {
        return ultimo_resultado;
    }

    /**
     * @param ultimo_resultado the ultimo_resultado to set
     */
    public void setUltimo_resultado(int ultimo_resultado) {
        this.ultimo_resultado = ultimo_resultado;
    }
}
