package proyecto2.cariaco.ceballos;

import java.util.concurrent.Semaphore;
import javax.swing.JOptionPane;

/**
 *
 * @author Juan Ceballos
 */
public class Interfaz extends javax.swing.JFrame {
    
    private Semaphore s;
    private SistemaOperativo sistema;
    private Procesador procesador;

    public Interfaz() {
        initComponents();
        this.setLocationRelativeTo(null);
        this.setSize(950, 800);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        comenzarJuego = new javax.swing.JButton();
        inputPersonajesIniciales = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        cola1Capcom = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        cola2Capcom = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        cola3Capcom = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        refuerzoCapcom = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        cola1Nintendo = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        cola2Nintendo = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        cola3Nintendo = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        refuerzoNintendo = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        colaGanadores = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        ganadoresNintendo = new javax.swing.JLabel();
        ganadoresCapcom = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        estadoProcesador = new javax.swing.JLabel();
        modificarTiempo = new javax.swing.JButton();
        inputTiempoProcesador = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        comenzarJuego.setText("Comenzar Juego");
        comenzarJuego.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comenzarJuegoActionPerformed(evt);
            }
        });
        getContentPane().add(comenzarJuego, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 200, -1, -1));

        inputPersonajesIniciales.setText("10");
        inputPersonajesIniciales.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputPersonajesInicialesActionPerformed(evt);
            }
        });
        getContentPane().add(inputPersonajesIniciales, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 150, 150, 30));

        jLabel1.setText("Duración de cada combate (segundos):");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 20, -1, -1));

        jLabel2.setText("Cola 1:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 190, -1, -1));

        cola1Capcom.setText("Vacía");
        getContentPane().add(cola1Capcom, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 230, -1, -1));

        jLabel4.setText("Cola 2:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 280, -1, -1));

        cola2Capcom.setText("Vacía");
        getContentPane().add(cola2Capcom, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 330, -1, -1));

        jLabel6.setText("Cola 3:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 380, -1, -1));

        cola3Capcom.setText("Vacía");
        getContentPane().add(cola3Capcom, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 420, -1, -1));

        jLabel8.setText("Cola de refuerzo:");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 470, -1, -1));

        refuerzoCapcom.setText("Vacía");
        getContentPane().add(refuerzoCapcom, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 510, -1, -1));

        jLabel10.setText("Capcom");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 150, -1, -1));

        jLabel11.setText("Cola 1:");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 180, -1, -1));

        cola1Nintendo.setText("Vacía");
        getContentPane().add(cola1Nintendo, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 230, -1, -1));

        jLabel13.setText("Cola 2:");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 280, -1, -1));

        cola2Nintendo.setText("Vacía");
        getContentPane().add(cola2Nintendo, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 320, -1, -1));

        jLabel15.setText("Cola 3:");
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 370, -1, -1));

        cola3Nintendo.setText("Vacía");
        getContentPane().add(cola3Nintendo, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 420, -1, -1));

        jLabel17.setText("Cola de refuerzo:");
        getContentPane().add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 470, -1, -1));

        refuerzoNintendo.setText("Vacía");
        getContentPane().add(refuerzoNintendo, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 510, -1, -1));

        jLabel19.setText("Nintendo");
        getContentPane().add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 140, -1, -1));

        jLabel20.setText("Ganadores");
        getContentPane().add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 620, -1, -1));

        colaGanadores.setText("Vacía");
        getContentPane().add(colaGanadores, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 660, -1, -1));

        jLabel22.setText("Ganadores:");
        getContentPane().add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 550, -1, -1));

        jLabel23.setText("Ganadores:");
        getContentPane().add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 560, -1, -1));

        ganadoresNintendo.setText("0");
        getContentPane().add(ganadoresNintendo, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 590, 30, 20));

        ganadoresCapcom.setText("0");
        getContentPane().add(ganadoresCapcom, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 580, 30, 30));

        jLabel26.setText("Estado procesador:");
        getContentPane().add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 380, -1, -1));

        estadoProcesador.setText("Esperando");
        getContentPane().add(estadoProcesador, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 410, 80, 20));

        modificarTiempo.setText("Modificar tiempo");
        modificarTiempo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modificarTiempoActionPerformed(evt);
            }
        });
        getContentPane().add(modificarTiempo, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 40, -1, -1));

        inputTiempoProcesador.setText("10");
        inputTiempoProcesador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputTiempoProcesadorActionPerformed(evt);
            }
        });
        getContentPane().add(inputTiempoProcesador, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 40, 150, 30));

        jLabel3.setText("Número de personajes iniciales:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 120, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void comenzarJuegoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comenzarJuegoActionPerformed
        try {
            if (Integer.parseInt(inputPersonajesIniciales.getText()) > 0 && Integer.parseInt(inputTiempoProcesador.getText()) > 0) {
                s = new Semaphore(1, true);
                sistema = new SistemaOperativo(s, Integer.parseInt(inputPersonajesIniciales.getText()));
                procesador = new Procesador(s, Integer.parseInt(inputTiempoProcesador.getText()));
                
                Proceso auxCapcom = sistema.escogerCompetidorEmpresa("C");
                Proceso auxNintendo = sistema.escogerCompetidorEmpresa("N");
                
                sistema.setCapcom(auxCapcom);
                sistema.setNintendo(auxNintendo);
                procesador.setCapcom(auxCapcom);
                procesador.setNintendo(auxNintendo);
                
                while (true) {
                    s.acquire();
                    procesador.setEstado_actual("Decidiendo");
                    estadoProcesador.setText(procesador.getEstado_actual());
                    s.release();
                    
                    procesador.start();
                    
                    s.acquire();
                    procesador.setEstado_actual("Anunciando");
                    estadoProcesador.setText(procesador.getEstado_actual());
                    s.release();
                    
                    s.acquire();
                    procesador.setEstado_actual("Esperando");
                    estadoProcesador.setText(procesador.getEstado_actual());
                    sistema.setUltimo_resultado(procesador.getUltimo_resultado());
                    s.release();
                    
                    sistema.start();
                    
                    s.acquire();
                    cola1Nintendo.setText(sistema.getNivel_1_N().imprimir());
                    cola2Nintendo.setText(sistema.getNivel_2_N().imprimir());
                    cola3Nintendo.setText(sistema.getNivel_3_N().imprimir());
                    cola1Capcom.setText(sistema.getNivel_1_C().imprimir());
                    cola2Capcom.setText(sistema.getNivel_2_C().imprimir());
                    cola3Capcom.setText(sistema.getNivel_3_C().imprimir());
                    refuerzoNintendo.setText(sistema.getRefuerzo_N().imprimir());
                    refuerzoNintendo.setText(sistema.getRefuerzo_C().imprimir());
                    colaGanadores.setText(sistema.getGanadores().imprimir());
                    ganadoresNintendo.setText(String.valueOf(sistema.getGanadores_nintendo()));
                    ganadoresCapcom.setText(String.valueOf(sistema.getGanadores_capcom()));
                    
                    procesador.setCapcom(sistema.getCapcom());
                    procesador.setNintendo(sistema.getNintendo());
                    s.release();
                }
            } else {
                
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error, por favor, inténtelo de nuevo");
        }
    }//GEN-LAST:event_comenzarJuegoActionPerformed

    private void inputPersonajesInicialesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputPersonajesInicialesActionPerformed
        
    }//GEN-LAST:event_inputPersonajesInicialesActionPerformed

    private void inputTiempoProcesadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputTiempoProcesadorActionPerformed
       
    }//GEN-LAST:event_inputTiempoProcesadorActionPerformed

    private void modificarTiempoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modificarTiempoActionPerformed
        try {
            if (Integer.parseInt(inputTiempoProcesador.getText()) > 0) {
                s.acquire();
                procesador.setTiempo(Integer.parseInt(inputTiempoProcesador.getText()));
                s.release();
            } else {
                
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error, por favor, inténtelo de nuevo");
        }
    }//GEN-LAST:event_modificarTiempoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Interfaz().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel cola1Capcom;
    private javax.swing.JLabel cola1Nintendo;
    private javax.swing.JLabel cola2Capcom;
    private javax.swing.JLabel cola2Nintendo;
    private javax.swing.JLabel cola3Capcom;
    private javax.swing.JLabel cola3Nintendo;
    private javax.swing.JLabel colaGanadores;
    private javax.swing.JButton comenzarJuego;
    private javax.swing.JLabel estadoProcesador;
    private javax.swing.JLabel ganadoresCapcom;
    private javax.swing.JLabel ganadoresNintendo;
    private javax.swing.JTextField inputPersonajesIniciales;
    private javax.swing.JTextField inputTiempoProcesador;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JButton modificarTiempo;
    private javax.swing.JLabel refuerzoCapcom;
    private javax.swing.JLabel refuerzoNintendo;
    // End of variables declaration//GEN-END:variables
}
