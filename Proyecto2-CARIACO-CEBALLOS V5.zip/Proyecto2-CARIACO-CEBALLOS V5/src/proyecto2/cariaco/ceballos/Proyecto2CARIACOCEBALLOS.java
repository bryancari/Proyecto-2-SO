package proyecto2.cariaco.ceballos;

/**
 *
 * @author Juan Ceballos
 */
public class Proyecto2CARIACOCEBALLOS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Interfaz interfaz = new Interfaz();
        interfaz.setVisible(true);
    }

}
