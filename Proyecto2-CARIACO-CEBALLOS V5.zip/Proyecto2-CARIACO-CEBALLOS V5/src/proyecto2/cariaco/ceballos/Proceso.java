package proyecto2.cariaco.ceballos;

/**
 * Clase que se encarga de definir a cada personaje sin importar la empresa a la que pertenezca, el cual es
 * equivalente a un proceso
 *
 * @author Juan Ceballos
 */
public class Proceso {

    private String id; //El ID es único para cada personaje, de modo que se puedan evitar repetidos
    private int prioridad;
    private int contador;
    private int habilidad;
    private int vida;
    private int fuerza;
    private int agilidad;
    private Proceso next; 

    /**
     * Constructor para el personaje
     *
     * @param newId El identificador único que diferenciará a para cada personaje 
     * @param prioridadInicial La prioridad inicial que tendrá el personaje a la hora de comenzar la simulación
     * @param habilidad Los puntos de habilidad
     * @param vida Los puntos de vida
     * @param fuerza Los puntos de fuerza
     * @param agilidad Los puntos de agilidad
     */
    public Proceso(String newId, int prioridadInicial, int habilidad, int vida, int fuerza, int agilidad) {
        this.id = newId;
        this.prioridad = prioridadInicial;
        this.contador = 0;
        this.habilidad = habilidad;
        this.fuerza = fuerza;
        this.agilidad = agilidad;
        this.vida = vida;
        this.next = null;
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return the prioridad
     */
    public int getPrioridad() {
        return prioridad;
    }

    /**
     * @param prioridad the prioridad to set
     */
    public void setPrioridad(int prioridad) {
        this.prioridad = prioridad;
    }

    /**
     * @return the contador
     */
    public int getContador() {
        return contador;
    }

    /**
     * @param contador the contador to set
     */
    public void setContador(int contador) {
        this.contador = contador;
    }

    /**
     * @return the next
     */
    public Proceso getNext() {
        return next;
    }

    /**
     * @param next the next to set
     */
    public void setNext(Proceso next) {
        this.next = next;
    }

    /**
     * @return the habilidad
     */
    public int getHabilidad() {
        return habilidad;
    }

    /**
     * @param habilidad the habilidad to set
     */
    public void setHabilidad(int habilidad) {
        this.habilidad = habilidad;
    }

    /**
     * @return the vida
     */
    public int getVida() {
        return vida;
    }

    /**
     * @param vida the vida to set
     */
    public void setVida(int vida) {
        this.vida = vida;
    }

    /**
     * @return the fuerza
     */
    public int getFuerza() {
        return fuerza;
    }

    /**
     * @param fuerza the fuerza to set
     */
    public void setFuerza(int fuerza) {
        this.fuerza = fuerza;
    }

    /**
     * @return the agilidad
     */
    public int getAgilidad() {
        return agilidad;
    }

    /**
     * @param agilidad the agilidad to set
     */
    public void setAgilidad(int agilidad) {
        this.agilidad = agilidad;
    }
}
